# noimage
A Google Chrome plug-in that whites out and removes visibility of all images on the internet.

<img src="http://www.keepcalmandposters.com/posters/1631300.png"></img>